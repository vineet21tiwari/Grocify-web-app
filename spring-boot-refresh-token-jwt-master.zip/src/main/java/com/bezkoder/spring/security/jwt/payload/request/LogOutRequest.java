package com.bezkoder.spring.security.jwt.payload.request;

public class LogOutRequest {
  private Long userId;

  public Long getUserId() {
    return this.userId;
  }
}
